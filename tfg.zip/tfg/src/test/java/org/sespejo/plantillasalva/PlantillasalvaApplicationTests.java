package org.sespejo.plantillasalva;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.salvaceloisma.tfg.PlantillaTFGApplication;

@SpringBootTest(classes = PlantillaTFGApplication.class)
class PlantillasalvaApplicationTests {

	@Test
	void contextLoads() {
	}

}
