package com.salvaceloisma.tfg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = PlantillaTFGApplication.class)
class TfgApplicationTests {

	@Test
	void contextLoads() {
	}

}
