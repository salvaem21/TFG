package com.salvaceloisma.tfg.exception;

public class InfoException extends Exception {
	public InfoException() {
		super();
	}

	public InfoException(String mensaje) {
		super(mensaje);
	}

}
