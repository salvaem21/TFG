package com.salvaceloisma.tfg.enumerados;

public enum Grados {
    DAW,
    DAM,
    ASIR,
    SMR
}
