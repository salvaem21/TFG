package com.salvaceloisma.tfg.enumerados;

//ENUMERADO PARA GRADOS PARA FACILITAR LA INCLUSION DE DISTINTOS GRADOS PARA UN FUTURO USO
public enum Grados {
    DAW,
    DAM,
    ASIR,
    SMR,
    AyF
}
