package com.salvaceloisma.tfg.enumerados;

public enum EstadoSolicitud {
    PENDIENTE_JEFATURA,
    PENDIENTE_ADJUNTAR_ARCHIVO,
    PENDIENTE_FIRMA_DIRECCION,
    PENDIENTE_FIRMA_JEFATURA,
    FINALIZADO_DIRECCION
}

