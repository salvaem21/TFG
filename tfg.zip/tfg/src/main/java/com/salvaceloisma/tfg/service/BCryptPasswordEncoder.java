package com.salvaceloisma.tfg.service;

public class BCryptPasswordEncoder {

    public String encode(String contrasenia) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'encode'");
    }

}
