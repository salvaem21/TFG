package com.salvaceloisma.tfg.exception;

public class DangerException extends Exception {
    public DangerException() {
		super();
	}
	public DangerException(String mensaje) {
		super(mensaje);
	}

}
