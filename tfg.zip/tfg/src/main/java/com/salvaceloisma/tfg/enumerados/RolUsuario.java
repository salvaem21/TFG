package com.salvaceloisma.tfg.enumerados;

//DISTINTOS ROLES PARA EL USO DE LA APLICACION
public enum RolUsuario {
    ADMIN,
    DIRECTOR,
    JEFATURA,
    PROFESOR
}
