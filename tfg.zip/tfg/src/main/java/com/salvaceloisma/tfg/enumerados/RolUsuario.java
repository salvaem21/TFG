package com.salvaceloisma.tfg.enumerados;

public enum RolUsuario {
    ADMIN,
    DIRECTOR,
    JEFATURA,
    PROFESOR,
    ALUMNO
}

